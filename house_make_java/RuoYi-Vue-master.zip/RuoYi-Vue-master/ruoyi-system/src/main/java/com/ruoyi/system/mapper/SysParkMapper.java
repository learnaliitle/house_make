package com.ruoyi.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.system.domain.SysPark;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysParkMapper extends BaseMapper<SysPark> {
}
